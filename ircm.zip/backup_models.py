# Create your models here.

# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models
from django.utils import timezone

class Yesno(models.Model):
    yesorno = models.CharField(db_column='YesOrNo', primary_key=True, max_length=3)  # Field name made lowercase.
    def __str__(self):
        return str(self.yesorno)

    class Meta:
        managed = False
        db_table = 'yesno'
        verbose_name = "Yes/No Option"
        verbose_name_plural = "Yes/No Options"

class Changes(models.Model):
    changeid = models.AutoField(db_column='ChangeID', primary_key=True)
    requestingtimestamp = models.DateTimeField("Change Request Timestamp", db_column='RequestingTimestamp', blank=False, null=False, help_text="Timestamp of the resquested change", auto_now_add=True)
    requestorstakeholder = models.ForeignKey('Stakeholders', models.DO_NOTHING, db_column='RequestorStakeholder', blank=True, null=True, verbose_name="Change Requestor Stakeholder", related_name='Requestor', help_text="Who requested the change")
    registerstakeholder = models.ForeignKey('Stakeholders', models.DO_NOTHING, db_column='RegisterStakeholder', blank=True, null=True, related_name='Register', verbose_name="Change Register Stakeholder", help_text="Who registered the change request")
    targetname = models.CharField("Change Target", db_column='TargetName', max_length=255, blank=True, null=True, help_text="Name of the repository affected")
    targetuniqueidentifier = models.TextField("Change Target Unique Identifier", db_column='TargetUniqueIdentifier', blank=True, null=True, help_text="e.g.: 'ReqID=22'")
    targetattribute = models.CharField("Change Target Attribute", db_column='TargetAttribute', max_length=255, blank=True, null=True, help_text="Name of the attribute in the repository affected")
    currentvalue = models.TextField("Change Target Current Value", db_column='CurrentValue', blank=True, null=True, help_text="Attribute current value")
    proposedvalue = models.TextField("Change Target Proposed Value", db_column='ProposedValue', blank=True, null=True, help_text="Attribute new proposed value")
    changerationale = models.TextField("Change Rationale", db_column='ChangeRationale', blank=True, null=True, help_text="Rationale for the change")
    approved = models.CharField("Change Approval Status", db_column='Approved', max_length=3, blank=True, null=True, help_text="YES or NO")
    approvingstakeholder = models.ForeignKey('Stakeholders', models.DO_NOTHING, db_column='ApprovingStakeholder', blank=True, null=True, related_name='Approver', verbose_name="Approving Stakeholder", help_text="Who approved the change")  # Field name made lowercase.
    approvingtimestamp = models.DateTimeField("Change Approving Timestamp", db_column='ApprovingTimestamp', blank=True, null=True, help_text="Timestamp when the change was approved")
    approvingdenialreason = models.TextField("Change Approval or Denial Reason", db_column='ApprovingDenialReason', blank=True, null=True, help_text="Reason of the approving/denial")
    designphase = models.ForeignKey('Stages', models.DO_NOTHING, db_column='DesignPhase', blank=True, null=True, verbose_name="Stage of Change", help_text="The design phase/stage in which the change took place")
    def __str__(self):
        return str(self.changeid)

    class Meta:
        managed = False
        db_table = 'changes'
        verbose_name = "Change"
        verbose_name_plural = "Changes"

class Parentchild01(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    parentid = models.ForeignKey('Desiresandneeds', models.DO_NOTHING, db_column='ParentID', blank=True, null=True, related_name='DN1')  # Field name made lowercase.
    childid = models.ForeignKey('Desiresandneeds', models.DO_NOTHING, db_column='ChildID', blank=True, null=True, related_name='DN2')  # Field name made lowercase.
    def __str__(self):
        return str(self.id)

    class Meta:
        managed = False
        db_table = 'parentchild01'
        verbose_name = "Multi-parent childs from Desires And Needs"
        verbose_name_plural = "Multi-parent childs from Desires And Needs"

class Parentchild02(models.Model):
    id = models.AutoField(db_column='ID', primary_key=True)  # Field name made lowercase.
    parentid = models.ForeignKey('Requirementslist', models.DO_NOTHING, db_column='ParentID', blank=True, null=True, related_name='RL1')  # Field name made lowercase.
    childid = models.ForeignKey('Requirementslist', models.DO_NOTHING, db_column='ChildID', blank=True, null=True, related_name='RL2')  # Field name made lowercase.
    def __str__(self):
        return str(self.id)

    class Meta:
        managed = False
        db_table = 'parentchild02'
        verbose_name = "Multi-parent childs from Requirements List"
        verbose_name_plural = "Multi-parent childs from Requirements List"



class Desiresandneeds(models.Model):
    globalid = models.AutoField(db_column='GlobalID', primary_key=True, help_text="Unique desire or need identifier", verbose_name="Unique Identifier")
    setname = models.CharField(db_column='SetName', max_length=255, blank=True, null=True, help_text="An opcional name for grouping desires and needs in sets", verbose_name="Set Name")
    label = models.CharField(db_column='Label', max_length=255, blank=True, null=True, help_text="Example: 3.1 (optional)", verbose_name="Label")
    parentid = models.ForeignKey('self', models.DO_NOTHING, db_column='ParentID', blank=True, null=True, related_name='DNParent', help_text="The ReqID of the requirement from which this requirement is derived", verbose_name="Parent ID")
    isalternativeforglobald = models.ForeignKey('self', models.DO_NOTHING, db_column='IsAlternativeForGlobalD', blank=True, null=True, related_name='DNAlternative', help_text="The ReqID of the requirement from which this requirement is a restatement", verbose_name="Is Restatment from")
    type = models.ForeignKey('Reqtypes', models.DO_NOTHING, db_column='Type', blank=True, null=True, help_text="Type of the desire or need (e.g.: Safety, Security, etc.)", verbose_name="Type")
    desireorneedtext = models.TextField(db_column='DesireOrNeedText', blank=True, null=True, help_text="Text of the desire or need", verbose_name="Statement")
    rationale = models.TextField(db_column='Rationale', blank=True, null=True, help_text="Rationale of the desire/need", verbose_name="Rationale")
    creationtimestamp = models.DateTimeField(db_column='CreationTimestamp', blank=False, null=False, auto_now_add=True, help_text="The timestamp of the creation of the desire/need in teh database", verbose_name="Creation Timestamp")
    creatorstakeholder = models.ForeignKey('Stakeholders', models.DO_NOTHING, db_column='CreatorStakeholder', blank=True, null=True, related_name='DNCreator', help_text="The stakeholder who created the desire or need in the database", verbose_name="Creator Stakeholder")
    requestorstakeholder = models.ForeignKey('Stakeholders', models.DO_NOTHING, db_column='RequestorStakeholder', blank=True, null=True, related_name='DNRequestor', help_text="The stakeholder who manifested the desire/need", verbose_name="Requestor Stakeholder")
    verifiervalidatorstakeholder = models.ForeignKey('Stakeholders', models.DO_NOTHING, db_column='VerifierValidatorStakeholder', blank=True, null=True, related_name='DNValidator', help_text="The stakeholder who will be in charge of V&V activities for this desire/need", verbose_name="V&V Stakeholder")
    level = models.ForeignKey('Reqlevels', models.DO_NOTHING, db_column='Level', blank=True, null=True, help_text="Stakeholder Requirement or System Requirement", verbose_name="Level")
    frozen = models.ForeignKey('Yesno', models.DO_NOTHING, db_column='Frozen', blank=True, null=True, help_text="If this desire/nedd is frozen or not", verbose_name="Frozen? (YES/NO)")
    freezerstakeholder = models.ForeignKey('Stakeholders', models.PROTECT, db_column='FreezerStakeholder', blank=True, null=True, related_name='DNFSH', help_text="The stakeholder who freezed the desire/need", verbose_name="Freezer Stakeholder")
    freezingtimestamp = models.DateTimeField(db_column='FreezingTimestamp', blank=True, null=True, help_text="The timestamp of the freezing", verbose_name="Freezing Timestamp")
    def __str__(self):
        return str(self.globalid)

    class Meta:
        managed = False
        db_table = 'desiresandneeds'
        verbose_name = "Desires And Needs"
        verbose_name_plural = "Desires And Needs"

class Hazards(models.Model):
    hazardid = models.AutoField(db_column='HazardID', primary_key=True)  # Field name made lowercase.
    hazarddescr = models.TextField(db_column='HazardDescr', blank=True, null=True)  # Field name made lowercase.
    def __str__(self):
        return str(self.hazardid)

    class Meta:
        managed = False
        db_table = 'hazards'
        verbose_name = "Hazard"
        verbose_name_plural = "Hazards"


class Hazardslist(models.Model):
    hazardlistid = models.AutoField(db_column='HazardListID', primary_key=True)  # Field name made lowercase.
    hazardlistname = models.CharField(db_column='HazardListName', max_length=255, blank=True, null=True)  # Field name made lowercase.
    hazardid = models.ForeignKey(Hazards, models.DO_NOTHING, db_column='HazardID', blank=True, null=True)  # Field name made lowercase.
    def __str__(self):
        return str(self.hazardlistid)

    class Meta:
        managed = False
        db_table = 'hazardslist'
        verbose_name = "Hazards List"
        verbose_name_plural = "Hazards List"


class Programs(models.Model):
    programname = models.CharField(db_column='ProgramName', primary_key=True, max_length=255)  # Field name made lowercase.
    programdescr = models.TextField(db_column='ProgramDescr', blank=True, null=True)  # Field name made lowercase.
    programowner = models.CharField(db_column='ProgramOwner', max_length=50, blank=True, null=True)  # Field name made lowercase.
    creationtimestamp = models.DateTimeField(db_column='CreationTimestamp', blank=True, null=True)  # Field name made lowercase.
    reqlistname = models.CharField(db_column='ReqListName', max_length=255, blank=True, null=True)  # Field name made lowercase.
    def __str__(self):
        return str(self.programname)

    class Meta:
        managed = False
        db_table = 'programs'
        verbose_name = "Program"
        verbose_name_plural = "Programs"


class Projects(models.Model):
    projectname = models.CharField(db_column='ProjectName', primary_key=True, max_length=255)  # Field name made lowercase.
    programname = models.ForeignKey(Programs, models.DO_NOTHING, db_column='ProgramName', blank=True, null=True)  # Field name made lowercase.
    projectdescr = models.TextField(db_column='ProjectDescr', blank=True, null=True)  # Field name made lowercase.
    projectowner = models.CharField(db_column='ProjectOwner', max_length=255, blank=True, null=True)  # Field name made lowercase.
    creationtimestamp = models.DateTimeField(db_column='CreationTimestamp', blank=True, null=True)  # Field name made lowercase.
    reqlistname = models.CharField(db_column='ReqListName', max_length=255, blank=True, null=True)  # Field name made lowercase.
    def __str__(self):
        return str(self.projectname)

    class Meta:
        managed = False
        db_table = 'projects'
        verbose_name = "Project"
        verbose_name_plural = "Projects"


class Reqlevels(models.Model):
    reqlevel = models.CharField(db_column='ReqLevel', primary_key=True, max_length=255)  # Field name made lowercase.
    def __str__(self):
        return str(self.reqlevel)

    class Meta:
        managed = False
        db_table = 'reqlevels'
        verbose_name = "Requirement Level"
        verbose_name_plural = "Requirement Levels"


class Reqtypes(models.Model):
    reqtype = models.CharField(db_column='ReqType', primary_key=True, max_length=255)  # Field name made lowercase.
    def __str__(self):
        return str(self.reqtype)

    class Meta:
        managed = False
        db_table = 'reqtypes'
        verbose_name = "Requirement Type"
        verbose_name_plural = "Requirement Types"


class Requirementslist(models.Model):
    reqid = models.AutoField(db_column='ReqID', primary_key=True)  # Field name made lowercase.
    originatingdesireorneed = models.ForeignKey(Desiresandneeds, models.DO_NOTHING, db_column='OriginatingDesireOrNeed', blank=True, null=True)  # Field name made lowercase.
    originatingrequirement = models.ForeignKey('self', models.DO_NOTHING, db_column='OriginatingRequirement', blank=True, null=True, related_name='RLOriginating')  # Field name made lowercase.
    programrequirementof = models.ForeignKey(Programs, models.DO_NOTHING, db_column='ProgramRequirementOf', blank=True, null=True)  # Field name made lowercase.
    projectrequirementof = models.ForeignKey(Projects, models.DO_NOTHING, db_column='ProjectRequirementOf', blank=True, null=True)  # Field name made lowercase.
    setname = models.CharField(db_column='SetName', max_length=255, blank=True, null=True)  # Field name made lowercase.
    reqlabel = models.CharField(db_column='ReqLabel', max_length=255, blank=True, null=True)  # Field name made lowercase.
    isalternativeof = models.ForeignKey('self', models.DO_NOTHING, db_column='IsAlternativeOf', blank=True, null=True, related_name='RLAlternative')  # Field name made lowercase.
    reqtype = models.ForeignKey(Reqtypes, models.DO_NOTHING, db_column='ReqType', blank=True, null=True)  # Field name made lowercase.
    reqtext = models.TextField(db_column='ReqText', blank=True, null=True)  # Field name made lowercase.
    rationale = models.TextField(db_column='Rationale', blank=True, null=True)  # Field name made lowercase.
    associationtimestamp = models.DateTimeField(db_column='AssociationTimestamp', blank=True, null=True)  # Field name made lowercase.
    associatorstakeholder = models.ForeignKey('Stakeholders', models.DO_NOTHING, db_column='AssociatorStakeholder', blank=True, null=True, related_name='RLAssociator')  # Field name made lowercase.
    verifiervalidatorstakeholder = models.ForeignKey('Stakeholders', models.DO_NOTHING, db_column='VerifierValidatorStakeholder', blank=True, null=True, related_name='RLValidator')  # Field name made lowercase.
    reqlevel = models.ForeignKey(Reqlevels, models.DO_NOTHING, db_column='ReqLevel', blank=True, null=True)  # Field name made lowercase.
    priority = models.IntegerField(db_column='Priority', blank=True, null=True)  # Field name made lowercase.
    stageofassociation = models.ForeignKey('Stages', models.DO_NOTHING, db_column='StageOfAssociation', blank=True, null=True)  # Field name made lowercase.
    vvmethod = models.ForeignKey('Verificationvalidationmethods', models.DO_NOTHING, db_column='VVMethod', blank=True, null=True)  # Field name made lowercase.
    frozen = models.ForeignKey('Yesno', models.DO_NOTHING, db_column='Frozen', blank=True, null=True)  # Field name made lowercase.
    freezerstakeholder = models.ForeignKey('Stakeholders', models.DO_NOTHING, db_column='FreezerStakeholder', blank=True, null=True, related_name='DNFreezer')  # Field name made lowercase.
    freezingtimestamp = models.DateTimeField(db_column='FreezingTimestamp', blank=True, null=True)  # Field name made lowercase.
    hazardlistid = models.ForeignKey(Hazardslist, models.DO_NOTHING, db_column='HazardListID', blank=True, null=True)  # Field name made lowercase.
    def __str__(self):
        return str(self.reqid)

    class Meta:
        managed = False
        db_table = 'requirementslist'
        verbose_name = "Requirement"
        verbose_name_plural = "Requirements"


class Stages(models.Model):
    stagename = models.CharField(db_column='StageName', primary_key=True, max_length=255)  # Field name made lowercase.
    def __str__(self):
        return str(self.stagename)

    class Meta:
        managed = False
        db_table = 'stages'
        verbose_name = "Stage"
        verbose_name_plural = "Stages"


class Stakeholders(models.Model):
    stakeholdername = models.CharField(db_column='StakeholderName', primary_key=True, max_length=255)  # Field name made lowercase.
    organizationname = models.TextField(db_column='OrganizationName', blank=True, null=True)  # Field name made lowercase.
    def __str__(self):
        return str(self.stakeholdername)

    class Meta:
        managed = False
        db_table = 'stakeholders'
        verbose_name = "Stakeholder"
        verbose_name_plural = "Stakeholders"


class Verificationvalidationmethods(models.Model):
    method = models.CharField(db_column='Method', primary_key=True, max_length=255)  # Field name made lowercase.
    def __str__(self):
        return str(self.method)

    class Meta:
        managed = False
        db_table = 'verificationvalidationmethods'
        verbose_name = "Verification and Validation Method"
        verbose_name_plural = "Verification and Validation Methods"
