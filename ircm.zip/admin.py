from django.contrib import admin

# Register your models here.
from .models import Changes
from .models import Desiresandneeds
from .models import Hazards
from .models import Hazardslist
from .models import Programs
from .models import Projects
from .models import Reqlevels
from .models import Reqtypes
from .models import Requirementslist
from .models import Stages
from .models import Stakeholders
from .models import Verificationvalidationmethods
from .models import Parentchild01
from .models import Parentchild02
from .models import Yesno
from .models import Vvactions
from .models import Vvevents
from .models import Vvstatus
from .models import Standards
from .models import Standardsclauses
from .models import Clauseslist
from .models import Violations
from .models import Assetclasses
from .models import Partnumbers
from .models import Manufacturers
from .models import Items
from .models import Assetrequirementslist
from .models import Interfaces
from .models import Interfacetypes
from .models import Configurationbaselines

class ChangesAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'requestingtimestamp',
                    'requestorstakeholder',
                    'registerstakeholder',
                    'targetname',
                    'targetuniqueidentifier',
                    'targetattribute',
                    'currentvalue',
                    'proposedvalue',
                    'changerationale',
                    'approved',
                    'approvingstakeholder',
                    'approvingtimestamp',
                    'approvingdenialreason',
                    'designphase'
                    )
    list_filter = ['requestorstakeholder','registerstakeholder','approvingstakeholder']
    search_fields = ['changerationale', 'approvingdenialreason']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('changeid','requestingtimestamp','requestorstakeholder','registerstakeholder','tobenotifiedstakeholder','targetname','targetuniqueidentifier','targetattribute','currentvalue','proposedvalue','changerationale',)
        return self.readonly_fields


class StandardsAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'standardname',
                    'standardissuer',
                    'standardyear',
                    )
    list_filter = ['standardissuer','standardyear']
    search_fields = ['standardname']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('standardname',)
        return self.readonly_fields

class StandardsclausesAdmin(admin.ModelAdmin):
    list_per_page = 5
    readonly_fields = ('clauseid',)
    list_display = (
                    'clauseid',
                    'standardname',
                    'standardclause',
                    )
    list_filter = ['standardname']
    search_fields = ['clausetext', 'standardclause']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('clauseid',)
        return self.readonly_fields

class ClauseslistAdmin(admin.ModelAdmin):
    list_per_page = 5
    readonly_fields = ('clauseslistid',)
    list_display = (
                    'clauseslistname',
                    'clauseid',
                    'reqid',
                    )
    list_filter = ['clauseslistname']
    search_fields = ['standardname', 'clausetext']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('clauseid', 'reqid',)
        return self.readonly_fields
    
class DesiresandneedsAdmin(admin.ModelAdmin):
    list_per_page = 5
    readonly_fields = ('globalid','creationtimestamp')
    list_display = (
                    'globalid',
                    'setname',
                    'frozen',
                    'label',
                    'parentid',
                    'isalternativeforglobald',
                    'type',
                    'creationtimestamp',
                    'creatorstakeholder',
                    'requestorstakeholder',
                    )
    list_filter = ['setname', 'requestorstakeholder', 'creatorstakeholder', 'frozen']
    search_fields = ['desireorneedtext', 'rationale']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('globalid', 'desireorneedtext', 'rationale','creationtimestamp','parentid','isalternativeforglobald','creatorstakeholder','requestorstakeholder',)
        return self.readonly_fields

class HazardsAdmin(admin.ModelAdmin):
    list_per_page = 5
    readonly_fields = ('hazardid',)
    list_display = (
                    'hazardid',
                    'hazarddescr',
                    )
    list_filter = ['hazarddescr']
    search_fields = ['hazarddescr']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('hazardid',)
        return self.readonly_fields

class HazardslistAdmin(admin.ModelAdmin):
    list_per_page = 5
    readonly_fields = ('hazardlistid',)
    list_display = (
                    'hazardlistname',
                    'hazardid',
                    'reqid'
                    )
    list_filter = ['hazardlistname']
    search_fields = ['hazardlistname']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('hazardlistid',)
        return self.readonly_fields

class ProjectsAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'projectname',
                    'programname',
                    'projectdescr',
                    'projectowner',
                    'creationtimestamp',
                    'reqlistname',
                    )
    list_filter = ['projectname','programname','projectowner',]
    search_fields = ['projectdescr']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('projectname',)
        return self.readonly_fields

class ProgramsAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'programname',
                    'programdescr',
                    'programowner',
                    'creationtimestamp',
                    'reqlistname',
                    )
    list_filter = ['programname','programdescr','programowner',]
    search_fields = ['projectdescr']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('programname',)
        return self.readonly_fields

class ReqlevelsAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'reqlevel',
                    'reqleveldescr',
                    )
    list_filter = ['reqlevel']
    search_fields = ['reqlevel', 'reqleveldescr']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('reqlevel',)
        return self.readonly_fields

class ReqtypesAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'reqtype',
                    )
    search_fields = ['reqtype']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('reqtype',)
        return self.readonly_fields

class RequirementslistAdmin(admin.ModelAdmin):
    list_per_page = 5
    readonly_fields = ('reqid','creationtimestamp',)
    list_display = (
                    'reqid',
                    'originatingdesireorneed',
                    'originatingrequirement',
                    'isalternativeof',
                    'creationtimestamp',
                    'programrequirementof',
                    'projectrequirementof',
                    'setname',
                    'associatorstakeholder',
                    'verifiervalidatorstakeholder',
                    'reqlevel',
                    'frozen',
                    )
    list_filter = [ 'programrequirementof',  'projectrequirementof', 'setname', 'associatorstakeholder','verifiervalidatorstakeholder','reqlevel','frozen']
    #search_fields = ['setname', 'associatorstakeholder','verifiervalidatorstakeholder','rationale']
    search_fields = ['rationale', 'reqtext', 'hazardlistname']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('reqid', 'reqtext', 'setname', 'programrequirementof', 'projectrequirementof', 'rationale',
                    'creationtimestamp', 'associationtimestamp', 'associatorstakeholder', 'originatingdesireorneed',
                    'reqlevel', 'originatingrequirement', 'isalternativeof', 'reqtype', 'verifiervalidatorstakeholder', 'stageofassociation', )
            #'stagetobevv'
        return self.readonly_fields

class StagesAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'stagename',
                    )
    search_fields = ['stagename']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('stagename',)
        return self.readonly_fields

class StakeholdersAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'stakeholdername',
                    'organizationname',
                    )
    list_filter = ['stakeholdername', 'organizationname']
    search_fields = ['stakeholdername', 'organizationname']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('stakeholdername', 'organizationname',)
        return self.readonly_fields

class VerificationvalidationmethodsAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'method',
                    )
    search_fields = ['method']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('method',)
        return self.readonly_fields

    
class VvactionsAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'vvaction',
                    )
    search_fields = ['vvaction']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('vvaction',)
        return self.readonly_fields

class VvstatusAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'status',
                    )
    search_fields = ['status']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('status',)
        return self.readonly_fields

class VveventsAdmin(admin.ModelAdmin):
    list_per_page = 5
    readonly_fields = ('id',)
    list_display = (
                    'id',
                    'reqid',
                    'assetid',
                    'eventaction',
                    'eventtimestamp',
                    'eventmethod',
                    'eventstatus',
                    'mainviolation',
                    'executorstakeholder',
                    )
    list_filter = ['eventmethod',]
    search_fields = ['eventdescr']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('id', 'reqid', 'assetid', 'eventaction', 'eventtimestamp', 'eventmethod', 'eventstatus', 'mainviolation', 'executorstakeholder', 'eventdescr',)
        return self.readonly_fields

class Parentchild01Admin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'parentid',
                    'childid',
                    )
    list_filter = ['parentid', 'childid']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('id', )
        return self.readonly_fields

class Parentchild02Admin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'parentid',
                    'childid',
                    )
    list_filter = ['parentid', 'childid']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('id', )
        return self.readonly_fields


class ViolationsAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'metric',
                    )
    list_filter = ['metric',]
    search_fields = ['description']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('metric', 'description',)
        return self.readonly_fields


class AssetclassesAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'assetclass',
                    )
    search_fields = ['assetclass']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('assetclass', )
        return self.readonly_fields

class ItemsAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'id',
                    'name',
                    'configurationbaseline',
                    'serialnumber',
                    'tag',
                    'partnumber',
                    'vendornickname',
                    'ownernickname',
                    'parentassetid',
                    )
    search_fields = ['name', 'configurationbaseline', 'serialnumber', 'partnumber', 'tag', 'vendornickname']
#    def get_readonly_fields(self, request, obj=None):
#        if obj: # editing an existing object
#            return ('id', 'name', 'configurationbaseline', 'serialnumber', 'tag', 'partnumber', 'vendornickname', 'count', 'ownernickname', 'parentassetid', 'creatorstakeholder', 'creationtimestamp', 'fqfn', 'note', 'requirementssetname',)
#            return ('id', )
#        return self.readonly_fields

class PartnumbersAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'ourpartnumber',
                    'ourdescription',
                    'manufacturernickname',
                    'class_field',
                    'isalternativefor',                    
                    )
    search_fields = ['ourpartnumber', 'manufacturernickname']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('ourpartnumber', 'ourdescription', 'manufacturernickname', 'manufacturerpartnumber', 'manufacturerdescription', 'class_field', 'isalternativefor', 'requirementssetname',)
        return self.readonly_fields


class ManufacturersAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'manufacturernickname',
                    'erpid',
                    )
    search_fields = ['manufacturernickname']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('manufacturernickname', 'erpid', )
        return self.readonly_fields

class AssetrequirementslistAdmin(admin.ModelAdmin):
    list_per_page = 5
    readonly_fields = ('id',)
    fieldsets= [
            (None,                                 {'fields': ['listname', 'reqid']}),
            ('Choose C.I. ID or Part Number:',     {'fields': ['assetid', 'partnumberid']}),
    ]
    list_display = (
                    'listname',
                    'assetid',
                    'partnumberid',
                    'reqid',
                    )
    list_filter = ['listname']
    search_fields = ['listname']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('id',)
        return self.readonly_fields

class InterfacesAdmin(admin.ModelAdmin):
    list_per_page = 5
    readonly_fields = ('id',)
    list_display = (
                    'partnumber1',
                    'partnumber2',
                    'interfacename',
                    'interfacetype',
                    'connquantity',
                    )
    list_filter = ['interfacename']
    search_fields = ['interfacename']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('id', 'partnumber1', 'partnumber2', 'interfacename', 'interfacetype', 'connquantity',)
        return self.readonly_fields

class InterfacetypesAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'interfacetype',
                    )
    list_filter = ['interfacetype']
    search_fields = ['interfacetype']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('interfacetype', )
        return self.readonly_fields

class ConfigurationbaselinesAdmin(admin.ModelAdmin):
    list_per_page = 5
    list_display = (
                    'baselinename',
                    'creationtimestamp',
                    'creatorstakeholder',
                    'frozen',
                    )
    list_filter = ['baselinename']
    search_fields = ['baselinename']
    def get_readonly_fields(self, request, obj=None):
        if obj: # editing an existing object
            return ('baselinename', 'creationtimestamp', 'creatorstakeholder', 'frozen',)
        return self.readonly_fields


admin.site.register(Changes, ChangesAdmin)
admin.site.register(Desiresandneeds, DesiresandneedsAdmin)
admin.site.register(Hazards, HazardsAdmin)
admin.site.register(Hazardslist, HazardslistAdmin)
admin.site.register(Programs, ProgramsAdmin)
admin.site.register(Projects, ProjectsAdmin)
admin.site.register(Reqlevels, ReqlevelsAdmin)
admin.site.register(Reqtypes, ReqtypesAdmin)
admin.site.register(Requirementslist, RequirementslistAdmin)
admin.site.register(Stages, StagesAdmin)
admin.site.register(Stakeholders, StakeholdersAdmin)
admin.site.register(Verificationvalidationmethods, VerificationvalidationmethodsAdmin)
admin.site.register(Vvactions, VvactionsAdmin)
admin.site.register(Vvstatus, VvstatusAdmin)
admin.site.register(Vvevents, VveventsAdmin)
admin.site.register(Parentchild01, Parentchild01Admin)
admin.site.register(Parentchild02, Parentchild02Admin)
admin.site.register(Standards, StandardsAdmin )
admin.site.register(Standardsclauses, StandardsclausesAdmin)
admin.site.register(Clauseslist, ClauseslistAdmin )
admin.site.register(Violations, ViolationsAdmin )
admin.site.register(Assetclasses, AssetclassesAdmin )
admin.site.register(Manufacturers, ManufacturersAdmin )
admin.site.register(Partnumbers, PartnumbersAdmin )
admin.site.register(Items, ItemsAdmin )
admin.site.register(Assetrequirementslist, AssetrequirementslistAdmin)
admin.site.register(Interfaces, InterfacesAdmin )
admin.site.register(Interfacetypes, InterfacetypesAdmin )
admin.site.register(Configurationbaselines, ConfigurationbaselinesAdmin )
admin.site.register(Yesno)


