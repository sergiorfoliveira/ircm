class ircmRouter(object):
    """
    A router to control all database operations on models in the
    ircm application.
    """
    def db_for_read(self, model, **hints):
        """
        Attempts to read ircm models go to ircm database.
        """
        if model._meta.app_label == 'ircm':
            return 'ircm'
        return None

    def db_for_write(self, model, **hints):
        """
        Attempts to write ircm models go to ircm database.
        """
        if model._meta.app_label == 'ircm':
            return 'ircm'
        return None

    def allow_relation(self, obj1, obj2, **hints):
        """
        Allow relations if a model in the ircm app is involved.
        """
        if obj1._meta.app_label == 'ircm' or \
           obj2._meta.app_label == 'ircm':
           return True
        return None

    def allow_migrate(self, db, app_label, model_name=None, **hints):
        """
        Make sure the ircm app only appears in the ircm database
        database.
        """
        if app_label == 'ircm':
            return db == 'ircm'
        return None
