from django.apps import AppConfig


class IrcmConfig(AppConfig):
    name = 'ircm'
