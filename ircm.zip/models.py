# Create your models here.

# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models
from django.utils import timezone


class Assetclasses(models.Model):
    assetclass = models.CharField(db_column='AssetClass',
                                  primary_key=True,
                                  max_length=255,
                                  verbose_name="CI Class",
                                  help_text="CI Class")
    def __str__(self):
        return str(self.assetclass)

    class Meta:
        managed = False
        db_table = 'assetclasses'
        verbose_name = "Configuration Item Class"
        verbose_name_plural = "Configuration Item Classes"

class Assetrequirementslist(models.Model):
    id = models.AutoField(db_column='ID',
                          primary_key=True,
                          help_text="Unique Identifier",
                          verbose_name="List Unique Identifier")
    listname = models.CharField(db_column='ListName',
                                max_length=255,
                                blank=False,
                                null=False,
                                help_text="List Name",
                                verbose_name="List Name")
    assetid = models.ForeignKey('Items',
                                models.PROTECT,
                                db_column='AssetID',
                                blank=True,
                                null=True,
                                help_text="Inform one: Configuration Item ID or Part Number (mutually exclusive)",
                                verbose_name="C.I. Unique Identifier" )
    partnumberid = models.ForeignKey('Partnumbers',
                                     models.PROTECT,
                                     db_column='PartNumberID',
                                     blank=True,
                                     null=True,
                                     help_text="Inform one: Configuration Item ID or Part Number (mutually exclusive)",
                                     verbose_name="Part Number " )
    reqid = models.ForeignKey('Requirementslist',
                              models.PROTECT,
                              db_column='ReqID',
                              blank=True,
                              null=True,
                              help_text="Requirement ID",
                              verbose_name="Requirement Unique Identifier " )
    def __str__(self):
        return str(self.id)

    class Meta:
        managed = False
        db_table = 'assetrequirementslist'
        verbose_name = "Item Requirement List"
        verbose_name_plural = "Item Requirement Lists"

        
class Changes(models.Model):
    changeid = models.AutoField(db_column='ChangeID',
                                primary_key=True)
    requestingtimestamp = models.DateTimeField("Change Request Timestamp",
                                               db_column='RequestingTimestamp',
                                               blank=False,
                                               null=False,
                                               help_text="Timestamp of the resquested change",
                                               auto_now_add=True)
    requestorstakeholder = models.ForeignKey('Stakeholders',
                                             models.PROTECT,
                                             db_column='RequestorStakeholder',
                                             blank=True, null=True,
                                             verbose_name="Change Requestor Stakeholder",
                                             related_name='Requestor', help_text="Who requested the change")
    registerstakeholder = models.ForeignKey('Stakeholders',
                                            models.PROTECT,
                                            db_column='RegisterStakeholder',
                                            blank=True,
                                            null=True,
                                            related_name='Register',
                                            verbose_name="Change Register Stakeholder",
                                            help_text="Who registered the change request")
    tobenotifiedstakeholder = models.ForeignKey('Stakeholders',
                                                models.PROTECT,
                                                db_column='ToBeNotifiedStakeholder',
                                                blank=True,
                                                null=True,
                                                related_name='Notified',
                                                verbose_name="To Be Notified Stakeholder",
                                                help_text="The primary stakeholder to be notified about the change")
    targetname = models.CharField("Change Target",
                                  db_column='TargetName',
                                  max_length=255,
                                  blank=True,
                                  null=True,
                                  help_text="Name of the repository affected")
    targetuniqueidentifier = models.CharField("Change Target Unique Identifier",
                                              db_column='TargetUniqueIdentifier',
                                              max_length=255,
                                              blank=True,
                                              null=True,
                                              help_text="e.g.: 'ReqID=22'")
    targetattribute = models.CharField("Change Target Attribute",
                                       db_column='TargetAttribute',
                                       max_length=255,
                                       blank=True,
                                       null=True,
                                       help_text="Name of the attribute in the repository affected")
    currentvalue = models.TextField("Change Target Current Value",
                                    db_column='CurrentValue',
                                    blank=True,
                                    null=True, help_text="Attribute current value")
    proposedvalue = models.TextField("Change Target Proposed Value",
                                     db_column='ProposedValue',
                                     blank=True,
                                     null=True,
                                     help_text="Attribute new proposed value")
    changerationale = models.TextField("Change Rationale",
                                       db_column='ChangeRationale',
                                       blank=True,
                                       null=True,
                                       help_text="Rationale for the change")
    approved = models.ForeignKey('Yesno',
                                 models.PROTECT,
                                 db_column='Approved',
                                 max_length=3,
                                 blank=False,
                                 null=False,
                                 help_text="YES or NO")
    approvingstakeholder = models.ForeignKey('Stakeholders',
                                             models.PROTECT,
                                             db_column='ApprovingStakeholder',
                                             blank=True,
                                             null=True,
                                             related_name='Approver',
                                             verbose_name="Approving Stakeholder",
                                             help_text="Who approved the change")  # Field name made lowercase.
    approvingtimestamp = models.DateTimeField("Change Approving Timestamp",
                                              db_column='ApprovingTimestamp',
                                              blank=True,
                                              null=True,
                                              help_text="Timestamp when the change was approved")
    approvingdenialreason = models.TextField("Change Approval or Denial Reason",
                                             db_column='ApprovingDenialReason',
                                             blank=True,
                                             null=True,
                                             help_text="Reason of the approving/denial")
    designphase = models.ForeignKey('Stages',
                                    models.PROTECT,
                                    db_column='DesignPhase',
                                    blank=True,
                                    null=True,
                                    verbose_name="Stage of Change",
                                    help_text="The design phase/stage in which the change took place")
    def __str__(self):
        return str(self.changeid)

    class Meta:
        managed = False
        db_table = 'changes'
        verbose_name = "Change"
        verbose_name_plural = "Changes"

class Clauseslist(models.Model):
    clauseslistid = models.AutoField(db_column='ClausesListID',
                                     primary_key=True,
                                     help_text="Unique Clause List ID",
                                     verbose_name="Unique Clause List ID")  
    clauseslistname = models.CharField(db_column='ClausesListName',
                                       max_length=45,
                                       blank=True,
                                       null=True,
                                       help_text="Clause List Name",
                                       verbose_name="Clause List Name") 
    clauseid = models.ForeignKey('Standardsclauses',
                                 models.PROTECT,
                                 db_column='ClauseID',
                                 blank=True,
                                 null=True,
                                 help_text="Unique Clause ID",
                                 verbose_name="Unique Clause ID") 
    reqid = models.ForeignKey('Requirementslist',
                              models.PROTECT,
                              db_column='ReqID',
                              blank=True,
                              null=True,
                              help_text="Unique Requirement ID",
                              verbose_name="Unique Requirement ID") 
    def __str__(self):
        return str(self.clauseslistid)

    class Meta:
        managed = False
        db_table = 'clauseslist'
        verbose_name = "Clauses List"
        verbose_name_plural = "Clauses Lists"


class Configurationbaselines(models.Model):
    baselinename = models.CharField(db_column='BaselineName',
                                    primary_key=True, max_length=255,
                                    verbose_name="Configuration Baseline Name",
                                    help_text="Configuration Baseline Name")
    creationtimestamp = models.DateTimeField(db_column='CreationTimestamp',
                                             blank=False, null=False,
                                             verbose_name="Creation Timestamp",
                                             help_text="The date/time of the baseline creation")  
    creatorstakeholder = models.ForeignKey('Stakeholders',
                                           models.PROTECT,
                                           db_column='CreatorStakeholder',
                                           blank=False,
                                           null=False,
                                           related_name='SH1',
                                           help_text="The stakeholder who created the configuration baseline",
                                           verbose_name="Creator Stakeholder")
    frozen = models.ForeignKey('Yesno',
                               models.PROTECT,
                               db_column='Frozen',
                               blank=True,
                               null=True,
                               help_text="If this desire/nedd is frozen or not",
                               verbose_name="Frozen? (YES/NO)")
    freezerstakeholder = models.ForeignKey('Stakeholders',
                                           models.PROTECT,
                                           db_column='FreezerStakeholder',
                                           blank=True,
                                           null=True,
                                           related_name='SH2',
                                           help_text="The stakeholder who has frozen the configuration baseline",
                                           verbose_name="Freezer Stakeholder")
    freezingtimestamp = models.DateTimeField(db_column='FreezingTimestamp',
                                             blank=True,
                                             null=True,
                                             help_text="The timestamp of the freezing",
                                             verbose_name="Freezing Timestamp")  
    note = models.TextField(db_column='Note',
                            blank=True,
                            null=True,
                            verbose_name="Note",
                            help_text="Note")  
    def __str__(self):
        return str(self.baselinename)

    class Meta:
        managed = False
        db_table = 'configurationbaselines'
        verbose_name = "Configuration Baseline"
        verbose_name_plural = "Configuration Baselines"


class Desiresandneeds(models.Model):
    globalid = models.AutoField(db_column='GlobalID',
                                primary_key=True,
                                help_text="Unique desire or need identifier",
                                verbose_name="Unique Identifier")
    setname = models.CharField(db_column='SetName',
                               max_length=255,
                               blank=True,
                               null=True, help_text="An opcional name for grouping desires and needs in sets",
                               verbose_name="Set Name")
    label = models.CharField(db_column='Label',
                             max_length=255,
                             blank=True,
                             null=True,
                             help_text="Example: 3.1 (optional)",
                             verbose_name="Label")
    parentid = models.ForeignKey('self',
                                 models.PROTECT,
                                 db_column='ParentID',
                                 blank=True,
                                 null=True,
                                 related_name='DNParent',
                                 help_text="The ReqID of the requirement from which this requirement is derived",
                                 verbose_name="Parent ID")
    isalternativeforglobald = models.ForeignKey('self',
                                                models.PROTECT,
                                                db_column='IsAlternativeForGlobalD',
                                                blank=True, null=True, related_name='DNAlternative',
                                                help_text="The ReqID of the requirement from which this requirement is a restatement",
                                                verbose_name="Is Restatment from")
    type = models.ForeignKey('Reqtypes',
                             models.PROTECT, db_column='Type',
                             blank=True, null=True,
                             help_text="Type of the desire or need (e.g.: Safety, Security, etc.)",
                             verbose_name="Type")
    desireorneedtext = models.TextField(db_column='DesireOrNeedText',
                                        blank=True,
                                        null=True,
                                        help_text="Text of the desire or need",
                                        verbose_name="Statement")
    rationale = models.TextField(db_column='Rationale',
                                 blank=True,
                                 null=True,
                                 help_text="Rationale of the desire/need",
                                 verbose_name="Rationale")
    creationtimestamp = models.DateTimeField(db_column='CreationTimestamp',
                                             blank=False,
                                             null=False,
                                             auto_now_add=True,
                                             help_text="The timestamp of the creation of the desire/need in teh database",
                                             verbose_name="Creation Timestamp")
    creatorstakeholder = models.ForeignKey('Stakeholders',
                                           models.PROTECT,
                                           db_column='CreatorStakeholder',
                                           blank=True,
                                           null=True,
                                           related_name='DNCreator',
                                           help_text="The stakeholder who created the desire or need in the database",
                                           verbose_name="Creator Stakeholder")
    requestorstakeholder = models.ForeignKey('Stakeholders',
                                             models.PROTECT,
                                             db_column='RequestorStakeholder',
                                             blank=True,
                                             null=True,
                                             related_name='DNRequestor',
                                             help_text="The stakeholder who manifested the desire/need",
                                             verbose_name="Requestor Stakeholder")
    verifiervalidatorstakeholder = models.ForeignKey('Stakeholders',
                                                     models.PROTECT,
                                                     db_column='VerifierValidatorStakeholder',
                                                     blank=True,
                                                     null=True,
                                                     related_name='DNValidator',
                                                     help_text="The stakeholder who will be in charge of V&V activities for this desire/need",
                                                     verbose_name="V&V Stakeholder")
    frozen = models.ForeignKey('Yesno',
                               models.PROTECT,
                               db_column='Frozen',
                               blank=True,
                               null=True,
                               help_text="If this desire/nedd is frozen or not",
                               verbose_name="Frozen? (YES/NO)")
    freezerstakeholder = models.ForeignKey('Stakeholders',
                                           models.PROTECT, db_column='FreezerStakeholder',
                                           blank=True,
                                           null=True,
                                           related_name='DNFSH',
                                           help_text="The stakeholder who freezed the desire/need",
                                           verbose_name="Freezer Stakeholder")
    freezingtimestamp = models.DateTimeField(db_column='FreezingTimestamp',
                                             blank=True,
                                             null=True,
                                             help_text="The timestamp of the freezing",
                                             verbose_name="Freezing Timestamp")
    def __str__(self):
        return str(self.globalid)

    class Meta:
        managed = False
        db_table = 'desiresandneeds'
        verbose_name = "Desires And Needs"
        verbose_name_plural = "Desires And Needs"

class Hazards(models.Model):
    hazardid = models.AutoField(db_column='HazardID',
                                primary_key=True,
                                help_text="Unique Hazard identifier",
                                verbose_name="Unique Identifier")
    hazarddescr = models.TextField(db_column='HazardDescr',
                                   blank=True,
                                   null=True,
                                   help_text="Hazard description",
                                   verbose_name="Hazard")
    def __str__(self):
        return str(self.hazardid)

    class Meta:
        managed = False
        db_table = 'hazards'
        verbose_name = "Hazard"
        verbose_name_plural = "Hazards"


class Hazardslist(models.Model):
    hazardlistid = models.AutoField(db_column='HazardListID',
                                    primary_key=True,
                                    help_text="Unique Identifier",
                                    verbose_name="List Unique Identifier")
    hazardlistname = models.CharField(db_column='HazardListName',
                                      max_length=255,
                                      blank=True,
                                      null=True,
                                      help_text="Hazards List Name",
                                      verbose_name="Hazards List Name")
    hazardid = models.ForeignKey(Hazards,
                                 models.PROTECT,
                                 db_column='HazardID',
                                 blank=True,
                                 null=True,
                                 help_text="Hazard Unique Identifier",
                                 verbose_name="Hazard Unique Identifier" )
    reqid = models.ForeignKey('Requirementslist',
                              models.PROTECT,
                              db_column='ReqID',
                              blank=True,
                              null=True,
                              help_text="Requirement Unique Identifier",
                              verbose_name="Requirement Unique Identifier" )
    def __str__(self):
        return str(self.hazardlistid)

    class Meta:
        managed = False
        db_table = 'hazardslist'
        verbose_name = "Hazards List"
        verbose_name_plural = "Hazards List"


class Items(models.Model):
    id = models.AutoField(db_column='ID',
                          primary_key=True,
                          verbose_name="Item. Unique Identifier",
                          help_text="C.I or Asset Unique Identifier")  
    name = models.CharField(db_column='Name',
                           max_length=255,
                           blank=False,
                           null=False,
                           verbose_name="Name",
                           help_text="Item Name")
    configurationbaseline = models.ForeignKey('ConfigurationBaselines',
                                              models.PROTECT, db_column='ConfigurationBaseline',
                                              blank=False,
                                              null=False,
                                              verbose_name="Configuration Baseline",
                                              help_text="Configuration Baseline Name")
    serialnumber = models.CharField(db_column='SerialNumber',
                                    max_length=255, blank=True,
                                    null=True,
                                    verbose_name="Serial Number",
                                    help_text="Serial Number, if any")  
    tag = models.CharField(db_column='Tag',
                           max_length=255,
                           blank=True,
                           null=True,
                           verbose_name="Tag",
                           help_text="Item Tag, if any")
    partnumber = models.ForeignKey('Partnumbers',
                                   models.PROTECT,
                                   db_column='PartNumber',
                                   blank=False,
                                   null=False,
                                   verbose_name="Our Part Number",
                                   help_text="Our Part Number")
    vendornickname = models.CharField(db_column='VendorNickname',
                                      max_length=255,
                                      blank=True,
                                      null=True,
                                      verbose_name="Vendor Nickname",
                                      help_text="Vendor Nickname from which the asset was purchased, if any") 
    ownernickname = models.CharField(db_column='OwnerNickname',
                                     max_length=255,
                                     blank=False,
                                     null=False,
                                     verbose_name="Ownner Nickname",
                                     help_text="The Organization the C.I. belongs to")  
    count = models.DecimalField(db_column='Count',
                                decimal_places=2,
                                max_digits=9,
                                blank=True,
                                null=True,
                                verbose_name="Count",
                                help_text="The count of this Item in its parent Item or in the current configuration baseline")
    parentassetid = models.ForeignKey('self',
                                      models.PROTECT,
                                      db_column='ParentAssetID',
                                      blank=True,
                                      null=True,
                                      verbose_name="Parent C.I. ID",
                                      help_text="Parent Item ID, if any")  
    creatorstakeholder = models.ForeignKey('Stakeholders',
                                           models.PROTECT,
                                           db_column='CreatorStakeholder',
                                           blank=True,
                                           null=True,
                                           help_text="The stakeholder who created the Item",
                                           verbose_name="Creator Stakeholder")
    creationtimestamp = models.DateTimeField(db_column='CreationTimestamp',
                                          blank=True,
                                          null=True,
                                          verbose_name="Creation Timestamp",
                                          help_text="The date/time of the usage reading")  
    fqfn = models.TextField(db_column='FQFN',
                            blank=True, null=True,
                            verbose_name="Fully Qualified Filename",
                            help_text="Fully Qualified Filename, if appropriate (used when the Item is a document)")  
    note = models.TextField(db_column='Note',
                            blank=True,
                            null=True,
                            verbose_name="Note",
                            help_text="Note")  
    requirementssetname = models.CharField(db_column='RequirementsSetName',
                                           max_length=255,
                                           blank=True,
                                           null=True,
                                           help_text="Requirements Set Name",
                                           verbose_name="Requirements Set Name")  
    def __str__(self):
        return str(self.id)

    class Meta:
        managed = False
        db_table = 'Items'
        verbose_name = "Item"
        verbose_name_plural = "Items"


class Interfaces(models.Model):
    id = models.AutoField(db_column='ID',
                          primary_key=True)  
    partnumber1 = models.ForeignKey('Partnumbers',
                                    models.PROTECT,
                                    db_column='PartNumber1',
                                    blank=False,
                                    null=False,
                                    related_name='PN1',
                                    help_text="The Containing PN",
                                    verbose_name="Part Number 1")  
    partnumber2 = models.ForeignKey('Partnumbers',
                                    models.PROTECT,
                                    db_column='PartNumber2',
                                    blank=False, null=False,
                                    related_name='PN2',
                                    help_text="The Contained PN",
                                    verbose_name="Part Number 2")  
    interfacename = models.CharField(db_column='InterfaceName',
                                     max_length=255,
                                     blank=True,
                                     null=True,
                                     help_text="Interface Name",
                                     verbose_name="Interface Name")  
    interfacetype = models.ForeignKey('Interfacetypes',
                                      models.PROTECT,
                                      db_column='InterfaceType',
                                      blank=False,
                                      null=False,
                                      help_text="Interface Type",
                                      verbose_name="Interface Type")  
    connquantity = models.IntegerField(db_column='ConnQuantity',
                                       blank=True,
                                       null=True,
                                       help_text="Home many PN2 ca be connected to PN1",
                                       verbose_name="Connections Qty")  
    def __str__(self):
        return str(self.id)

    class Meta:
        managed = False
        db_table = 'interfaces'
        verbose_name = "Interface"
        verbose_name_plural = "Interfaces"


class Interfacetypes(models.Model):
    interfacetype = models.CharField(db_column='InterfaceType',
                                     primary_key=True,
                                     max_length=255,
                                     help_text="Interface Type",
                                     verbose_name="Interface Type")  
    def __str__(self):
        return str(self.interfacetype)

    class Meta:
        managed = False
        db_table = 'interfacetypes'
        verbose_name = "Interface Type"
        verbose_name_plural = "Interface Types"



class Manufacturers(models.Model):
    manufacturernickname = models.CharField(db_column='ManufacturerNickName',
                                            primary_key=True,
                                            max_length=255,
                                            help_text="Manufacturer Nickname",
                                            verbose_name="Manufacturer Nickname")
    erpid = models.CharField(db_column='ERPid',
                             max_length=255,
                             blank=True,
                             null=True,
                             help_text="Manufacturer ERP ID, if any",
                             verbose_name="Manufacturer ERP ID")
    def __str__(self):
        return str(self.manufacturernickname)

    class Meta:
        managed = False
        db_table = 'manufacturers'
        verbose_name = "Manufacturer"
        verbose_name_plural = "Manufacturers"

class Parentchild01(models.Model):
    id = models.AutoField(db_column='ID',
                          primary_key=True,
                          help_text="Unique ID",
                          verbose_name="Unique ID") 
    parentid = models.ForeignKey('Desiresandneeds',
                                 models.PROTECT,
                                 db_column='ParentID',
                                 blank=True, null=True,
                                 related_name='DN1',
                                 help_text="Parent Desire/Need ID",
                                 verbose_name="Parent D/N ID")  
    childid = models.ForeignKey('Desiresandneeds',
                                models.PROTECT,
                                db_column='ChildID',
                                blank=True,
                                null=True,
                                related_name='DN2',
                                help_text="Child(Derived) Desire/Need ID",
                                verbose_name="Child(Derived) D/N ID")
    def __str__(self):
        return str(self.id)

    class Meta:
        managed = False
        db_table = 'parentchild01'
        verbose_name = "Multi-parent Derived D/N from Desires And Needs"
        verbose_name_plural = "Multi-parent Derived D/N from Desires And Needs"

class Parentchild02(models.Model):
    id = models.AutoField(db_column='ID',
                          primary_key=True,
                          help_text="Unique ID",
                          verbose_name="Unique ID") 
    parentid = models.ForeignKey('Requirementslist',
                                 models.PROTECT,
                                 db_column='ParentID',
                                 blank=True,
                                 null=True,
                                 related_name='RL1',
                                 help_text="Parent Req ID",
                                 verbose_name="Parent Req ID")
    childid = models.ForeignKey('Requirementslist',
                                models.PROTECT,
                                db_column='ChildID',
                                blank=True,
                                null=True,
                                related_name='RL2',
                                help_text="Child(Derived) Req ID",
                                verbose_name="Child(Derived) Req ID") 
    def __str__(self):
        return str(self.id)

    class Meta:
        managed = False
        db_table = 'parentchild02'
        verbose_name = "Multi-parent Derived Reqs from Requirements List"
        verbose_name_plural = "Multi-parent Derived Reqs from Requirements"


class Partnumbers(models.Model):
    ourpartnumber = models.CharField(db_column='OurPartNumber',
                                     primary_key=True,
                                     max_length=255,
                                     help_text="Our Part Number",
                                     verbose_name="Our Part Number") 
    ourdescription = models.TextField(db_column='OurDescription',
                                      blank=True,
                                      null=True,
                                      help_text="PN Description",
                                      verbose_name="PN Description")  
    manufacturernickname = models.ForeignKey(Manufacturers,
                                             models.PROTECT,
                                             db_column='ManufacturerNickname',
                                             blank=True,
                                             null=True,
                                             help_text="Manufacturer Nickname",
                                             verbose_name="Manufacturer Nickname") 
    manufacturerpartnumber = models.CharField(db_column='ManufacturerPartNumber',
                                              max_length=255,
                                              blank=True,
                                              null=True,
                                              help_text="Manufacturer Part Number",
                                              verbose_name="Manufacturer Part Number") 
    manufacturerdescription = models.TextField(db_column='ManufacturerDescription',
                                               blank=True,
                                               null=True,
                                               help_text="Manufacturer P/N Description",
                                               verbose_name="Manufacturer P/N Description") 
    class_field = models.ForeignKey(Assetclasses,
                                    models.PROTECT,
                                    db_column='Class',
                                    blank=True,
                                    null=True,
                                    help_text="P/N Class",
                                    verbose_name="P/N Class")  
    isalternativefor = models.CharField(db_column='IsAlternativeFor',
                                        max_length=255,
                                        blank=True,
                                        null=True,
                                        help_text="Whether the P/N is an alternative for another P/N",
                                        verbose_name="Alternative P/N")  
    requirementssetname = models.CharField(db_column='RequirementsSetName',
                                           max_length=255,
                                           blank=True,
                                           null=True,
                                           help_text="Requirements Set Name",
                                           verbose_name="Requirements Set Name")  
    def __str__(self):
        return str(self.ourpartnumber)

    class Meta:
        managed = False
        db_table = 'partnumbers'
        verbose_name = "Part Number"
        verbose_name_plural = "Part Numbers"

class Programs(models.Model):
    programname = models.CharField(db_column='ProgramName',
                                   primary_key=True,
                                   max_length=255,
                                   help_text="Program Name",
                                   verbose_name="Program Name")
    programdescr = models.TextField(db_column='ProgramDescr',
                                    blank=True,
                                    null=True,
                                    help_text="Program Description",
                                    verbose_name="Program Description") 
    programowner = models.ForeignKey('Stakeholders',
                                     models.PROTECT,
                                     db_column='ProgramOwner',
                                     blank=True, null=True,
                                     help_text="Owner Stakeholder",
                                     verbose_name="Owner Stakeholder") 
    creationtimestamp = models.DateTimeField(db_column='CreationTimestamp',
                                             blank=True,
                                             null=True,
                                             help_text="Creation Timestmp",
                                             verbose_name="Creation Timestamp",
                                             auto_now_add=True) 
    reqlistname = models.CharField(db_column='ReqListName',
                                   max_length=255,
                                   blank=True,
                                   null=True,
                                   help_text="Requirements List",
                                   verbose_name="Requirements List") 
    def __str__(self):
        return str(self.programname)

    class Meta:
        managed = False
        db_table = 'programs'
        verbose_name = "Program"
        verbose_name_plural = "Programs"


class Projects(models.Model):
    projectname = models.CharField(db_column='ProjectName',
                                   primary_key=True,
                                   max_length=255,
                                   help_text="Project Name",
                                   verbose_name="Project Name")
    programname = models.ForeignKey(Programs,
                                    models.PROTECT,
                                    db_column='ProgramName',
                                    blank=True, null=True,
                                    help_text="Program Name",
                                    verbose_name="Program Name")
    projectdescr = models.TextField(db_column='ProjectDescr',
                                    blank=True,
                                    null=True,
                                    help_text="Project Description",
                                    verbose_name="Project Description") 
    projectowner = models.ForeignKey('Stakeholders',
                                     models.PROTECT,
                                     db_column='ProjectOwner',
                                     blank=True,
                                     null=True,
                                     help_text="Project Owner",
                                     verbose_name="Project Owner")
    creationtimestamp = models.DateTimeField(db_column='CreationTimestamp',
                                             blank=True,
                                             null=True,
                                             help_text="Creation Timestamp",
                                             verbose_name="Creation Timestamp",
                                             auto_now_add=True) 
    reqlistname = models.CharField(db_column='ReqListName',
                                   max_length=255,
                                   blank=True,
                                   null=True,
                                   help_text="Program Name",
                                   verbose_name="Requirements List Name") 
    def __str__(self):
        return str(self.projectname)

    class Meta:
        managed = False
        db_table = 'projects'
        verbose_name = "Project"
        verbose_name_plural = "Projects"


class Reqlevels(models.Model):
    reqlevel = models.CharField(db_column='ReqLevel',
                                primary_key=True,
                                max_length=255,
                                help_text="Requirement Levels",
                                verbose_name="Requirement Level") 
    reqleveldescr = models.TextField(db_column='ReqLevelDescr',
                                     blank=True,
                                     null=True,
                                     help_text="Level Description",
                                     verbose_name="Level Description") 
    def __str__(self):
        return str(self.reqlevel)

    class Meta:
        managed = False
        db_table = 'reqlevels'
        verbose_name = "Requirement Level"
        verbose_name_plural = "Requirement Levels"


class Requirementslist(models.Model):
    reqid = models.AutoField(db_column='ReqID',
                             primary_key=True,
                             help_text="Unique requirement identifier in this list",
                             verbose_name="Requirement ID")
    originatingdesireorneed = models.ForeignKey(Desiresandneeds,
                                                models.PROTECT,
                                                db_column='OriginatingDesireOrNeed',
                                                blank=True, null=True,
                                                help_text="The GlobalID of the originating desire or need",
                                                verbose_name="Originating Desire or Need") 
    originatingrequirement = models.ForeignKey('self',
                                               models.PROTECT,
                                               db_column='OriginatingRequirement',
                                               blank=True,
                                               null=True,
                                               related_name='RLOriginating',
                                               help_text="Parent/Originating Requirement ID",
                                               verbose_name="Parent Requirement")  
    programrequirementof = models.ForeignKey(Programs,
                                             models.PROTECT,
                                             db_column='ProgramRequirementOf',
                                             blank=True, null=True,
                                             help_text="If it is a program requirement, then this attribute contains the Program Name, OTHERWISE LEAVE IT BLANK!",
                                             verbose_name="Program")  
    projectrequirementof = models.ForeignKey(Projects,
                                             models.PROTECT,
                                             db_column='ProjectRequirementOf',
                                             blank=True,
                                             null=True,
                                             help_text="If it is a project requirement, then this attribute contains the Project Name, OTHERWISE LEAVE IT BLANK!",
                                             verbose_name="Project")  
    creationtimestamp = models.DateTimeField("Creation Timestamp",
                                             db_column='CreationTimestamp',
                                             blank=False,
                                             null=False,
                                             help_text="Timestamp of the creation",
                                             auto_now_add=True)
    setname = models.CharField(db_column='SetName',
                               max_length=255,
                               blank=True,
                               null=True,
                               help_text="An opcional name for grouping requirements in sets",
                               verbose_name="Set Name")  
    reqlabel = models.CharField(db_column='ReqLabel',
                                max_length=255,
                                blank=True,
                                null=True,
                                help_text="Example: 2.5",
                                verbose_name="Label")  
    isalternativeof = models.ForeignKey('self',
                                        models.PROTECT,
                                        db_column='IsAlternativeOf',
                                        blank=True,
                                        null=True,
                                        related_name='RLAlternative',
                                        help_text="If this requirement is a restatement of another one already existing",
                                        verbose_name="Restatement Of")  
    reqtype = models.ForeignKey('Reqtypes',
                                models.PROTECT,
                                db_column='ReqType',
                                blank=True,
                                null=True,
                                help_text="Type of the requirement (e.g.: Safety, Security, etc.)",
                                verbose_name="Type")  
    reqtext = models.TextField(db_column='ReqText',
                               blank=True,
                               null=True,
                               help_text="Text/Statement of the requirement",
                               verbose_name="Text")  
    rationale = models.TextField(db_column='Rationale',
                                 blank=True,
                                 null=True,
                                 help_text="The rationale for associating that requirement to that project",
                                 verbose_name="Rationale")  
    associationtimestamp = models.DateTimeField(db_column='AssociationTimestamp',
                                                blank=True,
                                                null=True,
                                                help_text="The date/hour when the requirement was associated to the project or program",
                                                verbose_name="Associating Timestamp") 
    associatorstakeholder = models.ForeignKey('Stakeholders',
                                              models.PROTECT,
                                              db_column='AssociatorStakeholder',
                                              blank=True,
                                              null=True,
                                              related_name='RLAssociator',
                                              help_text="The stakeholder who associated the requirement to the project",
                                              verbose_name="Associator Stakeholder")  
    verifiervalidatorstakeholder = models.ForeignKey('Stakeholders',
                                                     models.PROTECT,
                                                     db_column='VerifierValidatorStakeholder',
                                                     blank=True,
                                                     null=True,
                                                     related_name='RLValidator',
                                                     help_text="The stakeholder who will be in charge of V&V activities for this requirement",
                                                     verbose_name="V&V Stakeholder")
    reqlevel = models.ForeignKey(Reqlevels,
                                 models.PROTECT,
                                 db_column='ReqLevel',
                                 blank=True,
                                 null=True,
                                 help_text="e.g: Stakeholder Requirement or System Requirement",
                                 verbose_name="Level")  
    priority = models.IntegerField(db_column='Priority',
                                   blank=True,
                                   null=True,
                                   help_text="The priority of that requirement for that Project or Program",
                                   verbose_name="Priority")  
    difficulty = models.IntegerField(db_column='Difficulty',
                                     blank=True,
                                     null=True,
                                     help_text="The greater the number the greater the difficulty",
                                     verbose_name="Difficulty")  
    stageofassociation = models.ForeignKey('Stages',
                                           models.PROTECT,
                                           db_column='StageOfAssociation',
                                           blank=True,
                                           null=True,
                                           help_text="The stage when the requirement was asssociated to the Project or Program",
                                           verbose_name="Stage of Association")  
    stagetobevv = models.ForeignKey('Stages',
                                    models.PROTECT,
                                    db_column='StageToBeVV',
                                    blank=True,
                                    null=True,
                                    related_name='VVStage',
                                    help_text="The stage before or at which the requirement must be verified or validated",
                                    verbose_name="Stage of Verification/Validation")  
    vvmethod = models.ForeignKey('Verificationvalidationmethods',
                                 models.PROTECT,
                                 db_column='VVMethod',
                                 blank=True,
                                 null=True,
                                 help_text="Recommended Varification/Validation method to be used",
                                 verbose_name="V&V Method")  
    frozen = models.ForeignKey('Yesno',
                               models.PROTECT,
                               db_column='Frozen',
                               blank=True,
                               null=True,
                               help_text="If this requirement is frozen or not",
                               verbose_name="Frozen?")  
    freezerstakeholder = models.ForeignKey('Stakeholders',
                                           models.PROTECT,
                                           db_column='FreezerStakeholder',
                                           blank=True,
                                           null=True,
                                           related_name='DNFreezer',
                                           help_text="The stakeholder who freezed the requirement",
                                           verbose_name="Freezer Stakeholder")  
    freezingtimestamp = models.DateTimeField(db_column='FreezingTimestamp',
                                             blank=True,
                                             null=True,
                                             help_text="The timestamp of the freezing",
                                             verbose_name="Freezing Timestamp")  
    hazardlistname = models.CharField(db_column='HazardListName',
                                      max_length=255,
                                      blank=True,
                                      null=True,
                                      help_text="Associated hazards list name (optional)",
                                      verbose_name="Hazards List Name")  
    stdclauseslistname = models.CharField(db_column='StdClausesListName',
                                          max_length=255,
                                          blank=True,
                                          null=True,
                                          help_text="Associated Standard or Regulation Clauses list name (optional)",
                                          verbose_name="Standards Clauses List Name")  

    def __str__(self):
        return str(self.reqid)

    class Meta:
        managed = False
        db_table = 'requirementslist'
        verbose_name = "Requirement"
        verbose_name_plural = "Requirements"


class Reqtypes(models.Model):
    reqtype = models.CharField(db_column='ReqType',
                               primary_key=True,
                               max_length=255,
                               help_text="Requirement Type",
                               verbose_name="Requirement Type") 
    def __str__(self):
        return str(self.reqtype)

    class Meta:
        managed = False
        db_table = 'reqtypes'
        verbose_name = "Requirement Type"
        verbose_name_plural = "Requirement Types"

class Standards(models.Model):
    standardname = models.CharField(db_column='StandardName',
                                    primary_key=True,
                                    max_length=255,
                                    help_text="Name of the Statandard",
                                    verbose_name="Name of the Statandard")
    standardissuer = models.CharField(db_column='StandardIssuer',
                                      max_length=255,
                                      blank=True,
                                      null=True,
                                      help_text="Standard Issuer",
                                      verbose_name="Standard Issuer") 
    standardyear = models.CharField(db_column='StandardYear',
                                    max_length=45,
                                    blank=True,
                                    null=True,
                                    help_text="Standard Year",
                                    verbose_name="Standard Year") 
    def __str__(self):
        return str(self.standardname)

    class Meta:
        managed = False
        db_table = 'standards'
        verbose_name = "Standard"
        verbose_name_plural = "Standards"

class Standardsclauses(models.Model):
    clauseid = models.AutoField(db_column='ClauseID',
                                primary_key=True,
                                help_text="Unique Clause ID",
                                verbose_name="Unique Clause ID") 
    standardname = models.ForeignKey('Standards',
                                     models.PROTECT,
                                     db_column='StandardName',
                                     blank=True,
                                     null=True,
                                     help_text="Standard Name",
                                     verbose_name="Standard Name") 
    standardclause = models.CharField(db_column='StandardClause',
                                      max_length=45,
                                      blank=True,
                                      null=True,
                                      help_text="Standard Clause or Paragraph",
                                      verbose_name="Standard Clause or Paragraph") 
    clausetext = models.TextField(db_column='ClauseText',
                                  blank=True,
                                  null=True, help_text="Clause Text",
                                  verbose_name="Clause Text")  
    def __str__(self):
        return str(self.clauseid)

    class Meta:
        managed = False
        db_table = 'standardsclauses'
        verbose_name = "Standard Clauses"
        verbose_name_plural = "Standard Clauses"

     

class Stages(models.Model):
    stagename = models.CharField(db_column='StageName',
                                 primary_key=True,
                                 max_length=255,
                                 help_text="e.g.: Preliminary Design",
                                 verbose_name="Stage") 
    def __str__(self):
        return str(self.stagename)

    class Meta:
        managed = False
        db_table = 'stages'
        verbose_name = "Stage"
        verbose_name_plural = "Stages"


class Stakeholders(models.Model):
    stakeholdername = models.CharField(db_column='StakeholderName',
                                       primary_key=True,
                                       max_length=255,
                                       help_text="Stakeholder Name",
                                       verbose_name="Stakeholder Name") 
    organizationname = models.TextField(db_column='OrganizationName',
                                        blank=True,
                                        null=True,
                                        help_text="Organization Name",
                                        verbose_name="Organization Name") 
    def __str__(self):
        return str(self.stakeholdername)

    class Meta:
        managed = False
        db_table = 'stakeholders'
        verbose_name = "Stakeholder"
        verbose_name_plural = "Stakeholders"


class Verificationvalidationmethods(models.Model):
    method = models.CharField(db_column='Method',
                              primary_key=True,
                              max_length=255,
                              help_text="e.g.: Demonstration",
                              verbose_name="Method") 
    def __str__(self):
        return str(self.method)

    class Meta:
        managed = False
        db_table = 'vvmethods'
        verbose_name = "Verification and Validation Method"
        verbose_name_plural = "Verification and Validation Methods"


class Violations(models.Model):
    metric = models.CharField(db_column='Metric',
                              primary_key=True,
                              max_length=255,
                              help_text="The violation metric name, according to ISO 29148:2011 clause 5.2",
                              verbose_name="Metric Name")  
    description = models.TextField(db_column='Description',
                                   blank=True,
                                   null=True,
                                   help_text="Description of the violation metric, according to ISO 29148:2011 clause 5.2",
                                   verbose_name="Violation Description") 
    def __str__(self):
        return str(self.metric)

    class Meta:
        managed = False
        db_table = 'violations'
        verbose_name = "Violation Metric"
        verbose_name_plural = "Violation Metrics"        


class Vvactions(models.Model):
    vvaction = models.CharField(db_column='VVAction',
                                primary_key=True,
                                max_length=45,
                                help_text="Verification or Validation",
                                verbose_name="Action")  
    def __str__(self):
        return str(self.vvaction)

    class Meta:
        managed = False
        db_table = 'vvactions'
        verbose_name = "Verification and Validation Action"
        verbose_name_plural = "Verification and Validation Actions"


class Vvevents(models.Model):
    id = models.AutoField(db_column='ID',
                          primary_key=True,
                          help_text="Unique ID",
                          verbose_name="Event ID")  
    reqid = models.ForeignKey(Requirementslist,
                              models.PROTECT,
                              db_column='ReqID',
                              blank=True,
                              null=True,
                              help_text="Requirements ID",
                              verbose_name="Requirement ID") 
    assetid = models.ForeignKey(Items,
                                models.PROTECT,
                                db_column='AssetID',
                                blank=True,
                                null=True,
                                help_text="C.I. or Asset ID, if any",
                                verbose_name="C.I. or Asset ID") 
    eventaction = models.ForeignKey(Vvactions,
                                    models.PROTECT,
                                    db_column='EventAction',
                                    blank=True,
                                    null=True,
                                    help_text="e.g.: Examination, Verification, Validation",
                                    verbose_name="Action")  
    eventtimestamp = models.DateTimeField(db_column='EventTimestamp',
                                          blank=True,
                                          null=True,
                                          help_text="Verification or Validation timestamp",
                                          verbose_name="Timestamp")  
    eventmethod = models.ForeignKey('Verificationvalidationmethods',
                                    models.PROTECT,
                                    db_column='EventMethod',
                                    blank=True,
                                    null=True,
                                    help_text="Verification or Validation Method",
                                    verbose_name="Method")  
    eventstatus = models.ForeignKey('Vvstatus',
                                    models.PROTECT,
                                    db_column='EventStatus',
                                    blank=True, null=True,
                                    help_text="Verification or Validation Status",
                                    verbose_name="Status")  
    mainviolation = models.ForeignKey('Violations',
                                      models.PROTECT,
                                      db_column='MainViolation',
                                      blank=True,
                                      null=True,
                                      help_text="Main violation reason, if any",
                                      verbose_name="Main Violation Reason")  
    executorstakeholder = models.ForeignKey(Stakeholders,
                                            models.PROTECT,
                                            db_column='ExecutorStakeholder',
                                            blank=True,
                                            null=True,
                                            help_text="Action executor",
                                            verbose_name="Executor")  
    eventdescr = models.TextField(db_column='EventDescr',
                                  blank=True,
                                  null=True,
                                  help_text="Event Description",
                                  verbose_name="Description") 
    def __str__(self):
        return str(self.id)

    class Meta:
        managed = False
        db_table = 'vvevents'
        verbose_name = "Verification and Validation Event"
        verbose_name_plural = "Verification and Validation Events"


class Vvstatus(models.Model):
    status = models.CharField(db_column='Status',
                              primary_key=True,
                              max_length=45,
                              help_text="Pass or Fail",
                              verbose_name="Status") 
    def __str__(self):
        return str(self.status)

    class Meta:
        managed = False
        db_table = 'vvstatus'
        verbose_name = "Verification and Validation Status"
        verbose_name_plural = "Verification and Validation Status"

class Yesno(models.Model):
    yesorno = models.CharField(db_column='YesOrNo',
                               primary_key=True,
                               max_length=3) 
    def __str__(self):
        return str(self.yesorno)

    class Meta:
        managed = False
        db_table = 'yesno'
        verbose_name = "Yes/No Option"
        verbose_name_plural = "Yes/No Options"
